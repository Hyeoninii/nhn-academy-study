//Quiz 5-8 prob 7
package quiz0508;

public class Prob7 {
    public void printUpperCase(String input) {
        System.out.println(input.toUpperCase());
    }

    public static void main(String[] args) {
        Prob7 obj = new Prob7();
        obj.printUpperCase("hello");
    }
} 