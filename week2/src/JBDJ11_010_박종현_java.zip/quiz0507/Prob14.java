//Quiz 5-7 prob 14
package quiz0507;

public class Prob14 {
    public static void main(String[] args) {
        System.out.println(MathOperations.square(5)); // 25 출력
    }
} 