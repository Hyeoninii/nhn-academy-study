package quiz0507;

public class Juice implements Drinkable {
    @Override
    public void drink() {
        System.out.println("주스를 마십니다.");
    }
} 