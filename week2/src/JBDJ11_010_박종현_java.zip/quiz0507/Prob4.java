//Quiz 5-7 prob 4
package quiz0507;

public class Prob4 {
    public static void main(String[] args) {
        MultiFunctionDevice device = new MultiFunctionDevice();
        device.print("Hello, World!"); // "Printing: Hello, World!" 출력
        System.out.println(device.scan()); // "Scanning..." 출력
    }

} 