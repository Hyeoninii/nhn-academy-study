package quiz0507;

public class Software implements Updatable {
    @Override
    public void update() {
        System.out.println("Updating software.");
    }
} 