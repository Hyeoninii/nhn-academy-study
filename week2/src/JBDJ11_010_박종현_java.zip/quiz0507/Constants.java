package quiz0507;

public interface Constants {
    int MAX_SPEED = 120;
    int MIN_SPEED = 10;
}
