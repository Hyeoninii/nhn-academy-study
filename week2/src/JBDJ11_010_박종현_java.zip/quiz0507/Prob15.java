//Quiz 5-7 prob 15
package quiz0507;

public class Prob15 {
    public static void main(String[] args) {
        Car car = new Car();
        car.move();  // "Car is moving." 출력
        car.stop();  // "Car is stopping." 출력
    }
} 