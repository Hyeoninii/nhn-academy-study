//Quiz 5-7 prob 6
package quiz0507;

public class Prob6 {
    public static void main(String[] args) {
        Car car = new Car();
        car.displaySpeedRange();
    }
}