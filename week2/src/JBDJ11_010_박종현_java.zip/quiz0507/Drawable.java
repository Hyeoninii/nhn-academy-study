package quiz0507;

public interface Drawable extends Shape{
    void draw();
}
