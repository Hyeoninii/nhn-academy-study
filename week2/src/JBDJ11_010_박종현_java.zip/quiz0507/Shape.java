package quiz0507;

public interface Shape {
    double getArea();
}
