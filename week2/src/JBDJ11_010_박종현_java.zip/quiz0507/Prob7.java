//Quiz 5-7 prob 7
package quiz0507;

public class Prob7 {
    public static void main(String[] args) {
        Person person = new Person();
        person.walk(); // "Person is walking." 출력
        person.run();  // "Person is running." 출력
    }

} 