package quiz0507;

public interface Edible {
    void eat();
} 