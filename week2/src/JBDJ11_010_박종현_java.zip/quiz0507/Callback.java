package quiz0507;

public interface Callback {
    void execute();
} 