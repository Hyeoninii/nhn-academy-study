package quiz0507;

public interface Scanner {
    String scan();
}
