//Quiz 5-7 prob 8
package quiz0507;

public class Prob8 {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();
        System.out.println(calculator.add(5, 10)); // 15 출력
        System.out.println(calculator.multiply(5, 10)); // 50 출력
    }
} 