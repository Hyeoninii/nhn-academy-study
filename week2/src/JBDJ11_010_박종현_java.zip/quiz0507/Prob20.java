//Quiz 5-7 prob 20
package quiz0507;

public class Prob20 {
    public static void main(String[] args) {
        Updatable app = new Software();
        app.update(); // "Updating software." 출력
        app.reset();  // "Resetting to default state." 출력
    }
} 