package quiz0507;

public class Apple implements Edible {
    @Override
    public void eat() {
        System.out.println("사과를 먹습니다.");
    }
} 