package quiz0507;

public class Airplane implements Flyable{
    @Override
    public void fly() {
        System.out.println("Airplane is flying.");
    }
}
