//Quiz 5-7 prob 19
package quiz0507;

public class Prob19 {
    public static void main(String[] args) {
        Pet myPet = new Dog();
        myPet.sound(); // "Woof!" 출력
        myPet.play();  // "Playing fetch." 출력
    }
} 