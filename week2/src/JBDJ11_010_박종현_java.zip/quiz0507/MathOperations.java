package quiz0507;

public interface MathOperations {
    static int square(int x) {
        return x * x;
    }
} 