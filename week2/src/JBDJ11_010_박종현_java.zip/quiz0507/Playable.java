package quiz0507;

public interface Playable {
    void play();
} 