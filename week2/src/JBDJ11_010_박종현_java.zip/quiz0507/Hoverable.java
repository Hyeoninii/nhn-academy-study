package quiz0507;

public interface Hoverable extends Flyable {
    void hover();
}
