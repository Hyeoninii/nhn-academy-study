//Quiz 5-7 prob 9
package quiz0507;

public class Prob9 {
    public static void main(String[] args) {
        Hoverable drone = new Drone();
        drone.fly();   // "Drone is flying." 출력
        drone.hover(); // "Drone is hovering." 출력
    }
} 