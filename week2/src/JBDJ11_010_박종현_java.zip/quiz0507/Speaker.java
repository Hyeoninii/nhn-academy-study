package quiz0507;

public interface Speaker {
    void speak();
} 