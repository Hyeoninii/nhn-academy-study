package quiz0507;

public interface Printer {
    void print(String content);
}
