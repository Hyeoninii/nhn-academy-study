//Quiz 5-7 prob 3
package quiz0507;

public class Prob3 {
    public static void main(String[] args) {
        Readable reader = new TextReader();
        System.out.println(reader.readLine());
    }
} 