package quiz0507;

public interface Drinkable {
    void drink();
} 