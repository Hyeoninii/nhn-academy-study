//Quiz 5-7 prob 1
package quiz0507;

public class Prob1 {
    public static void main(String[] args) {
        Drawable circle = new Circle();
        Drawable squre = new Rectangle();

        circle.draw();
        squre.draw();
    }
} 