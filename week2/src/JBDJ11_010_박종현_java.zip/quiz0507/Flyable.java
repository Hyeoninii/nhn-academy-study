package quiz0507;

public interface Flyable {
    void fly();
}
