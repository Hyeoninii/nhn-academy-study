//Quiz 5-7 prob 10
package quiz0507;

public class Prob10 {
    public static void main(String[] args) {
        Document doc = new Document();
        doc.read();         // "Reading the document." 출력
        doc.write();        // "Writing to the document." 출력
        doc.printType();    // 적절한 출력 작성
    }

} 