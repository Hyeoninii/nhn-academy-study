//Quiz 5-7 prob 13
package quiz0507;

public class Prob13 {
    public static void main(String[] args) {
        AppleJuice aj = new AppleJuice();
        aj.eat();
        aj.drink();  
    }
} 