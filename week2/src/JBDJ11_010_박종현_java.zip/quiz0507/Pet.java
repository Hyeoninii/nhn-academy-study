package quiz0507;

public interface Pet extends Animal {
    void play();
} 