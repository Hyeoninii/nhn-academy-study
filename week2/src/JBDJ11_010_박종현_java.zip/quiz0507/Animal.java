package quiz0507;

public interface Animal {
    void sound();
} 