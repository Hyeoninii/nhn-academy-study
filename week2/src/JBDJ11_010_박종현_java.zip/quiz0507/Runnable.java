package quiz0507;

public interface Runnable {
    void run();
}
