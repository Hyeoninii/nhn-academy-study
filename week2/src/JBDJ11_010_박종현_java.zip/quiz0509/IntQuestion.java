package quiz0509;

public interface IntQuestion {
    public String getQuestion();
    public int getCorrectAnswer();
}
