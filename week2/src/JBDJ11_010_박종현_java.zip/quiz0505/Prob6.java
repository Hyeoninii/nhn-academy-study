//Quiz 5-5 prob 5
package quiz0505;

public class Prob6 {
    public static void main(String[] args) {
        //final class는 override가 되지 않음
    }
}
