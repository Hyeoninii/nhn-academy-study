//Quiz 5-5 prob 11
package quiz0505;

public class Prob11 {
    public static void main(String[] args) {
        Shape r = new Rectangle(1);
        Shape c = new Circle(2);
        System.out.println(r.caculateArea());
        System.out.println(c.caculateArea());
    }
}
