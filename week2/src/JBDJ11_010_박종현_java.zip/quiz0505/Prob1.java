//Quiz 5-5 prob 1
package quiz0505;

public class Prob1 {
    public static void main(String[] args) {
        Car car = new Car(4);
        car.printInfo();
    }
}

