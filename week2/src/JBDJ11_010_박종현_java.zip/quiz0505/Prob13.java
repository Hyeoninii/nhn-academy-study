//Quiz 5-5 prob 13
package quiz0505;

public class Prob13 {
    public static void main(String[] args) {
        Animal bird = new Bird();
        Animal fish = new Fish();

        bird.move();
        fish.move();
    }
}
