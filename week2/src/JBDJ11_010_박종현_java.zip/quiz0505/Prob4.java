package quiz0505;

import org.w3c.dom.css.Rect;

public class Prob4 {
    public static void main(String[] args) {
        Shape r = new Rectangle();
        Shape o = new Oval();

        r.draw();
        o.draw();
    }
}
