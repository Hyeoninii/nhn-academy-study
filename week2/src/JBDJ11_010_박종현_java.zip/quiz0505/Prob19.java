//Quiz 5-5 prob 19
package quiz0505;

public class Prob19 {
    public static void main(String[] args) {
    }
}

class Vehicle19 {
    final void drive() {}
}
//class Car19 extends Vehicle19 {
//    @Override
//    void drive() {}
    // java: drive() in quiz0505.Car19 cannot override drive() in quiz0505.Vehicle19
    //  overridden method is final
//}