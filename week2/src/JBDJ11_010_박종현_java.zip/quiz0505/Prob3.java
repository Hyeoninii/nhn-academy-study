//Quiz 5-5 prob 3
package quiz0505;

public class Prob3 {
    public static void main(String[] args) {
        Shape r = new Rectangle();
        Shape c = new Circle();
        r.draw();
        c.draw();
    }
}
