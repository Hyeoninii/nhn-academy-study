package quiz0505;

public interface Drawable {
    void draw();
}
