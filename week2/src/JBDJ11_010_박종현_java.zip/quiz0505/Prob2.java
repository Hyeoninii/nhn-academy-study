//Quiz 5-5 prob 2
package quiz0505;

public class Prob2 {
    public static void main(String[] args) {
        Rectangle r = new Rectangle();
        r.draw();
    }
}
