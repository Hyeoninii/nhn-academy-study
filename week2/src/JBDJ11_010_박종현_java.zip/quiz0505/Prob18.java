//Quiz 5-5 prob 18
package quiz0505;

public class Prob18 {
    public static void main(String[] args) {
    }
}

final class Vehicle18 {

}
//class Car extends Vehicle18 {
    //java: cannot inherit from final quiz0505.Vehicle18
//}