//Quiz 5-10 prob 7
package quiz0510;

public class Prob7 {
}

class Player {
    private String name;
    private int score;

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }

    public int getScore() {
        return score;
    }
    public void setScore(int score) {
        this.score = score;
    }
}