//Quiz 5-6 prob 1
package quiz0506;

public class Prob1 {
}
