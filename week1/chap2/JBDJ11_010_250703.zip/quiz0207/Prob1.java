package quiz0207;

//Quiz 2-7 prob 1
public class Prob1 {
    public static void main(String[] args) {
        System.out.println();
        System.out.println("            *************     **      **");
        System.out.println("                 **           **      **");
        System.out.println("                 **           **      **");
        System.out.println("                 **           **      **");
        System.out.println("                 **           **********");
        System.out.println("          **     **           **      **");
        System.out.println("          **    **            **      **");
        System.out.println("           **  **             **      **");
        System.out.println("            ****              **      **");
        System.out.println();
    }
}