#Quiz 2-6 prob 1

#!/bin/bash
java --version