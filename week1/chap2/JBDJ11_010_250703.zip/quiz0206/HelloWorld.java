/*
 * javac HelloWorld.java를 하게 되면 HelloWorld.class라는 바이트코드를 생성한다.
 * java Helloworld를 통해서 바이트코드를 JVM이 실행하면 Hello, World!가 출력된다.
 */
package quiz0206;

//Quiz 2-6 prob 2
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello, World!");
    }
}
