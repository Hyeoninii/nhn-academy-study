package quiz0205;

public class Priority {
    public static void main(String[] args) {
        System.out.printf("(5 + 3) * 2 = %d%n", (5 + 3) * 2 );
        System.out.printf("5 + 3 * 2 = %d%n", 5 + 3 * 2);
        System.out.printf("(10 / 2) * (3 + 1) = %d%n",(10 / 2) * (3 + 1));
    }
}
