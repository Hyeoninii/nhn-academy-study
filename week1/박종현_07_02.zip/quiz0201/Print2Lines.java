package quiz0201;

//Quiz 2-1 문제  4
public class Print2Lines {
	public static void main(String[] args) {
		System.out.print("Hello, Java!\nLet's start coding.");
	}
}
