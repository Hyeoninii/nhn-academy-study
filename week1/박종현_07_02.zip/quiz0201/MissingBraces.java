package quiz0201;

//Quiz 2-1 문제  9
/*
중괄호는 함수나 클래스의 스코프를 나타낸다.
*/
public class MissingBraces {
	public static void main(String[] args) {
		System.out.println("This program has an error!");
	}
}
