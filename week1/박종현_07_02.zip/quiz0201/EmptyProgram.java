package quiz0201;

//Quiz 2-1 문제  7
public class EmptyProgram {
	public static void main(String[] args) {
	}
}
