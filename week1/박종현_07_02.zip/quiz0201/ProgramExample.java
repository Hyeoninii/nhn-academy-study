package quiz0201;

//Quiz 2-1 문제  6
//자바에서 파일 이름은 클래스 이름으로 하므로 ProgramExample.java로 작성
public class ProgramExample {
	public static void main(String[] args) {
		System.out.println("This is ProgramExample.");
	}
}
