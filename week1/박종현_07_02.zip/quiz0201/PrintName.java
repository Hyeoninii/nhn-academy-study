package quiz0201;

//Quiz 2-1 문제  2
public class PrintName {
    public static void main(String[] args) {
        System.out.println("My name is Jonghyeon");
    }
}