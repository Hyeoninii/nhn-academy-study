package quiz0201;

//Quiz 2-1 문제  3
public class ErrorExample {
	public static void main(String[] args) {
		System.out.println("This program has an error!");
	}
}
