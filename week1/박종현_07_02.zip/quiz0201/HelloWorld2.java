package quiz0201;

//Quiz 2-1 문제  5
/*
프로그램의 이름: HelloWorld
프로그램의 시작점
"Hello, World!"메세지를 출력
*/
public class HelloWorld2 {
	public static void main(String[] args) {
		System.out.println("Hello, World!");
	}
}
