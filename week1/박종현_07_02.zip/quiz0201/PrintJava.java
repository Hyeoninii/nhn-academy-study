package quiz0201;

//Quiz 2-1 문제  8
public class PrintJava {
	public static void main(String[] args) {
		System.out.print("Hello, ");
		System.out.println("Java!");
	}
}
