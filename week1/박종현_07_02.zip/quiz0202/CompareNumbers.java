package quiz0202;

//Quiz 2-2 문제 7
public class CompareNumbers {
    public static void main(String[] args) {
        int a = 10;
        int b = 5;
        boolean result = (a > b);
        System.out.println("a > b: " + result);
    }
}