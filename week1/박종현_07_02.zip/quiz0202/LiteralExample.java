package quiz0202;

//Quiz 2-2 문제 2
public class LiteralExample {
    public static void main(String[] args) {
        int largeNumber = 1_000_000;
        System.out.println(largeNumber);
    }
}