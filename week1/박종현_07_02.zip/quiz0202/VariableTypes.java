package quiz0202;

//Quiz 2-2 문제 6
public class VariableTypes {
    public static void main(String[] args) {
        int age = 25;
        float height = 5.9f;
        System.out.printf("나이: %d, 키: %.1f\n", age, height);
    }
}