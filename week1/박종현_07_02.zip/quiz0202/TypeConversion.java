package quiz0202;

//Quiz 2-2 문제 4
public class TypeConversion {
    public static void main(String[] args) {
        double rate = 0.07;
        System.out.printf("반환된 값: %d\n", (int)rate);
    }
}